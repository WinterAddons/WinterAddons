const renderX = 100;
const renderY = 120;
const renderZ = 200;

let showBox = false;

register("chat", () => {
    showBox = true;
    Client.showTitle("§dTiny Dancer!", "§bGo jump to her!", 10, 60, 10);
    World.playSound("note.pling", 1, 1);
    ChatLib.chat("§b[TD] §dTiny Dancer has appeared! Head to the marked location.");
}).setChatCriteria("Tiny Dancer has appeared!").setContains();

register("renderWorld", () => {
    if (!showBox) return;
    Tessellator.drawBox(
        RenderType.LINES,
        renderX, renderY, renderZ,
        renderX + 1, renderY + 1, renderZ + 1,
        0.8, 0.2, 1.0, 1,
        true
    );
});
